# Mi Voz IA

App Android (Capacitor) para guardar perfiles de voz y generar audio en español con XTTS-v2 gratis (Hugging Face).

## Cómo obtener el APK (sin Android Studio)
1. Crea una cuenta gratis en github.com y un repositorio nuevo (botón **New**, nombre `mi-voz-ia`).
2. En el repositorio: **Add file → Upload files** y arrastra TODO el contenido de esta carpeta (incluida la carpeta oculta `.github`). Pulsa **Commit changes**.
3. Abre la pestaña **Actions**: se compila solo (unos 5–10 min). Si no arranca, entra a «Compilar APK» → **Run workflow**.
4. Al terminar, abre **Releases** (columna derecha de la página principal) y descarga **MiVozIA.apk**.
5. Ábrelo en tu Honor X7c y acepta «Instalar apps desconocidas» cuando lo pida.

## Límites reales
- La clonación corre en un servidor gratuito de Hugging Face: puede tener cola o estar dormido (1–3 min).
- XTTS-v2 tiene licencia no comercial (CPML).
