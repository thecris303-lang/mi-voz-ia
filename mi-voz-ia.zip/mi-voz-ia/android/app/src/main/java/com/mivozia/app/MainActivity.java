package com.mivozia.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
