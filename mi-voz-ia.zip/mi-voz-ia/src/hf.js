import { Client, handle_file } from "@gradio/client";
let cache = { space: null, client: null };

export function pickAudio(data) {
  const files = (data || []).filter((x) => x && typeof x === "object" && (x.url || x.path));
  const isAudio = (x) => /\.(wav|mp3|flac|ogg|m4a)(\?|$)/i.test(x.url || x.path || x.orig_name || "");
  return files.find(isAudio) || null;
}

export async function synth({ space, text, lang, ref, onStatus }) {
  if (cache.space !== space) {
    onStatus("conectando con el servidor gratuito (si estaba dormido puede tardar 1 a 3 min)…");
    cache = { space, client: await Client.connect(space) };
  }
  const file = new File([ref], "voz.wav", { type: "audio/wav" });
  // Orden del Space coqui/xtts: texto, idioma, audio de referencia, micrófono, usar_mic, limpiar_voz, sin_autodetectar, acepto_términos
  const job = cache.client.submit("/predict", [text, lang, handle_file(file), null, false, false, false, true]);
  let data = null;
  for await (const m of job) {
    if (m.type === "status") {
      if (m.stage === "error") throw new Error(m.message || "error del servidor");
      onStatus(m.position != null ? `en cola (puesto ${m.position + 1})` : "procesando…");
    } else if (m.type === "data") data = m.data;
  }
  const f = pickAudio(data);
  if (!f) throw new Error("el servidor no devolvió audio" + (data && typeof data[2] === "string" ? ": " + data[2].slice(0, 120) : ""));
  const r = await fetch(f.url || f.path);
  if (!r.ok) throw new Error("no se pudo descargar el audio (" + r.status + ")");
  return await r.blob();
}
