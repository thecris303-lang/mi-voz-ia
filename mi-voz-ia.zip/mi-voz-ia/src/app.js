import { Capacitor } from "@capacitor/core";
import { Filesystem, Directory } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";
import * as db from "./store.js";
import * as A from "./audio.js";
import { synth } from "./hf.js";

const RATE = 24000, MAXREC = 30;
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const ls = (k, d) => localStorage.getItem(k) || d;
const st = { tab: "voces", voices: [], audios: [], sel: ls("sel", ""), fmt: ls("fmt", "mp3"), lang: ls("lang", "es"),
  space: ls("space", "coqui/xtts"), text: "", busy: false, result: null, draft: null };
const LANGS = { es: "Español", en: "Inglés", pt: "Portugués", fr: "Francés", it: "Italiano", de: "Alemán" };
let urls = [];
const url = (b) => { const u = URL.createObjectURL(b); urls.push(u); return u; };
const fmtDur = (s) => Math.round(s) + " s";

function toast(m) { const t = $("#toast"); t.textContent = m; t.className = "show"; clearTimeout(toast.t); toast.t = setTimeout(() => (t.className = ""), 3500); }
function ask(title, { input, ok = "Aceptar", cancel = "Cancelar", danger } = {}) {
  return new Promise((res) => {
    const m = document.createElement("div"); m.className = "modal";
    m.innerHTML = `<div><b>${esc(title)}</b>${input !== undefined ? `<input type="text" value="${esc(input)}" style="margin-top:12px">` : ""}
      <div class="row"><button data-x="0">${cancel}</button><button data-x="1" class="${danger ? "danger" : "primary"}">${ok}</button></div></div>`;
    document.body.appendChild(m); const i = $("input", m); if (i) { i.focus(); i.select(); }
    m.onclick = (e) => { const x = e.target.dataset.x; if (x === undefined) return; m.remove(); res(x === "1" ? (i ? i.value.trim() : true) : null); };
  });
}

async function load() {
  st.voices = (await db.all("voices")).sort((a, b) => a.created - b.created);
  st.audios = (await db.all("audios")).sort((a, b) => b.created - a.created);
  if (!st.voices.find((v) => v.id === st.sel)) st.sel = st.voices[0]?.id || "";
}

function render() {
  urls.forEach(URL.revokeObjectURL); urls = [];
  document.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("on", b.dataset.t === st.tab));
  const m = $("#main");
  if (st.tab === "voces") {
    m.innerHTML = `<h2>Mis voces</h2><p class="muted">Guarda voces tuyas o de personas que te hayan dado su permiso.</p>
      <button class="big primary" data-a="new">＋ Agregar nueva voz</button>` +
      (st.voices.length ? st.voices.map((v) => `<div class="card ${v.id === st.sel ? "sel" : ""}"><div class="row"><b>${esc(v.name)}</b><span class="muted">${fmtDur(v.dur)}</span></div>
        <div class="row"><button data-a="play" data-id="${v.id}">▶ Escuchar</button><button data-a="ren" data-id="${v.id}">Renombrar</button><button data-a="del" data-id="${v.id}" class="danger">Eliminar</button></div>
        <div class="row"><button data-a="use" data-id="${v.id}" ${v.id === st.sel ? "disabled" : ""}>${v.id === st.sel ? "Voz seleccionada" : "Usar esta voz"}</button></div>
        <audio id="a-${v.id}" hidden></audio></div>`).join("") : `<p class="muted" style="margin-top:24px">Todavía no tienes voces guardadas.</p>`);
  } else if (st.tab === "generar") {
    m.innerHTML = `<h2>Generar voz</h2>` + (st.voices.length ? `
      <select id="vsel">${st.voices.map((v) => `<option value="${v.id}" ${v.id === st.sel ? "selected" : ""}>${esc(v.name)}</option>`).join("")}</select>
      <div style="height:10px"></div><select id="lang">${Object.entries(LANGS).map(([k, n]) => `<option value="${k}" ${k === st.lang ? "selected" : ""}>${n}</option>`).join("")}</select>
      <div style="height:10px"></div><textarea id="txt" placeholder="Escribe aquí lo que quieres que diga tu voz…">${esc(st.text)}</textarea>
      <div style="height:12px"></div><button class="big primary" data-a="gen" ${st.busy ? "disabled" : ""}>${st.busy ? "GENERANDO…" : "GENERAR VOZ"}</button>
      <div class="status" id="msg"></div><div id="res"></div>
      <details><summary>Ajustes avanzados</summary><p class="muted">Servidor gratuito (Hugging Face Space) que clona la voz con XTTS-v2.</p>
      <input type="text" id="space" value="${esc(st.space)}"></details>` : `<p class="muted">Primero agrega una voz en la pestaña «Voces».</p>`);
    if (st.result) showResult($("#res"), st.result);
  } else {
    m.innerHTML = `<h2>Mis audios</h2>` + (st.audios.length ? st.audios.map((a) => `<div class="card"><div class="row"><b>${esc(a.voiceName)}</b><span class="muted">${new Date(a.created).toLocaleDateString("es")} · ${fmtDur(a.dur)}</span></div>
      <p class="muted" style="margin:6px 0">${esc(a.text.slice(0, 90))}${a.text.length > 90 ? "…" : ""}</p><audio controls src="${url(a.wav)}"></audio>
      <div class="row"><button data-a="save" data-id="${a.id}">Guardar</button><button data-a="share" data-id="${a.id}">Compartir</button><button data-a="dela" data-id="${a.id}" class="danger">Eliminar</button></div></div>`).join("")
      : `<p class="muted">Aquí aparecerán los audios que generes.</p>`);
  }
}

function showResult(el, r) {
  el.innerHTML = `<div class="card"><b>Resultado</b> <span class="muted">${fmtDur(r.dur)}</span><audio controls src="${url(r.wav)}"></audio>
    <div class="row"><span class="muted">Formato</span><div class="seg"><button data-f="mp3" class="${st.fmt === "mp3" ? "on" : ""}">MP3</button><button data-f="wav" class="${st.fmt === "wav" ? "on" : ""}">WAV</button></div></div>
    <div class="row"><button data-a="save" data-id="${r.id}">Guardar en el teléfono</button><button data-a="share" data-id="${r.id}" class="primary">Compartir</button></div></div>`;
}

// ---------- Guardar y compartir ----------
async function exportAudio(item) {
  const name = (item.voiceName + "-" + new Date(item.created).toISOString().slice(0, 16).replace(/[:T]/g, "")).replace(/[^\w-]+/g, "_");
  if (st.fmt === "wav") return { blob: item.wav, name: name + ".wav" };
  const s = await A.decodeBlob(item.wav, RATE);
  return { blob: A.encodeMp3(s, RATE), name: name + ".mp3" };
}
const b64 = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result.split(",")[1]); r.onerror = rej; r.readAsDataURL(blob); });

async function saveToPhone(item) {
  const { blob, name } = await exportAudio(item);
  if (Capacitor.isNativePlatform()) {
    await Filesystem.writeFile({ path: "MiVozIA/" + name, data: await b64(blob), directory: Directory.Documents, recursive: true });
    toast("Guardado en Documentos/MiVozIA/" + name);
  } else {
    const a = document.createElement("a"); a.href = url(blob); a.download = name; a.click(); toast("Descargando " + name);
  }
}
async function shareAudio(item) {
  const { blob, name } = await exportAudio(item);
  if (Capacitor.isNativePlatform()) {
    const f = await Filesystem.writeFile({ path: name, data: await b64(blob), directory: Directory.Cache });
    await Share.share({ title: "Mi Voz IA", files: [f.uri] });
  } else if (navigator.canShare && navigator.canShare({ files: [new File([blob], name, { type: blob.type })] })) {
    await navigator.share({ files: [new File([blob], name, { type: blob.type })] });
  } else { await saveToPhone(item); }
}
const findItem = (id) => (st.result && st.result.id === id ? st.result : st.audios.find((a) => a.id === id));

// ---------- Nueva voz ----------
let rec, stream, chunks, timer;
function sheet() {
  const d = st.draft, s = $("#sheet"); if (!d) { s.hidden = true; s.innerHTML = ""; return; }
  s.hidden = false;
  s.innerHTML = `<h2>Nueva voz</h2>
    <input type="text" id="vname" placeholder="Nombre de la voz (ej. Mi voz)" value="${esc(d.name)}">
    <label class="chk"><input type="checkbox" id="consent" ${d.consent ? "checked" : ""}><span>Confirmo que esta es mi propia voz o que la persona me dio su permiso para grabarla y usarla.</span></label>
    ${d.rec ? `<button class="big rec" data-a="stop">■ Detener (${d.secs} s)</button>` : `
    <button class="big primary" data-a="rec" ${d.consent ? "" : "disabled"}>● Grabar mi voz</button><div style="height:10px"></div>
    <button class="big" data-a="imp" ${d.consent ? "" : "disabled"}>Importar una grabación</button>
    <input type="file" id="file" accept="audio/*" hidden>`}
    <p class="muted">Lee un texto en voz natural durante 10 a 30 segundos, en un lugar silencioso.</p>
    ${d.wav ? `<div class="card"><b>Muestra lista</b> <span class="muted">${fmtDur(d.info.dur)}${d.info.hz ? " · tono aprox. " + d.info.hz + " Hz" : ""}</span>
      <audio controls src="${url(d.wav)}"></audio>${d.info.tips.map((t) => `<div class="tip">⚠ ${t}</div>`).join("")}</div>` : ""}
    <div class="row" style="margin-top:20px"><button data-a="cancel">Cancelar</button><button class="primary" data-a="saveVoice" ${d.wav && !d.rec ? "" : "disabled"}>Guardar voz</button></div>`;
}
async function useBlob(blob) {
  try {
    let s = await A.decodeBlob(blob, RATE); if (s.length > MAXREC * RATE) { s = s.slice(0, MAXREC * RATE); toast("Se usarán los primeros 30 segundos."); }
    if (s.length < 2 * RATE) throw new Error("la muestra dura menos de 2 segundos");
    Object.assign(st.draft, { wav: A.wavBlob(s, RATE), info: A.analyze(s, RATE) });
  } catch (e) { toast("No se pudo leer el audio: " + e.message); }
  sheet();
}
async function startRec() {
  try {
    stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  } catch (e) { return toast("Necesito permiso del micrófono para grabar."); }
  chunks = []; rec = new MediaRecorder(stream);
  rec.ondataavailable = (e) => chunks.push(e.data);
  rec.onstop = async () => { stream.getTracks().forEach((t) => t.stop()); clearInterval(timer); st.draft.rec = false; await useBlob(new Blob(chunks, { type: rec.mimeType })); };
  rec.start(); Object.assign(st.draft, { rec: true, secs: 0, wav: null }); sheet();
  timer = setInterval(() => { st.draft.secs++; const b = $("[data-a=stop]"); if (b) b.textContent = `■ Detener (${st.draft.secs} s)`; if (st.draft.secs >= MAXREC) rec.stop(); }, 1000);
}

// ---------- Generar ----------
const setMsg = (t) => { const e = $("#msg"); if (e) e.textContent = t; };
async function generate() {
  const v = st.voices.find((x) => x.id === st.sel), t = st.text.trim();
  if (!v) return toast("Elige una voz."); if (!t) return toast("Escribe un texto.");
  st.busy = true; st.result = null; render();
  try {
    const parts = A.splitText(t, 200), out = [];
    for (let i = 0; i < parts.length; i++) {
      const pre = parts.length > 1 ? `Parte ${i + 1} de ${parts.length}: ` : "";
      const b = await synth({ space: st.space, text: parts[i], lang: st.lang, ref: v.wav, onStatus: (m) => setMsg(pre + m) });
      out.push(await A.decodeBlob(b, RATE));
    }
    const s = A.concat(out, RATE, 0.3);
    const item = { id: db.uid(), text: t, voiceId: v.id, voiceName: v.name, created: Date.now(), wav: A.wavBlob(s, RATE), dur: s.length / RATE };
    await db.put("audios", item); st.audios.unshift(item); st.result = item; toast("¡Audio listo!");
  } catch (e) { st.msg = ""; toast("No se pudo generar: " + (e.message || e)); console.error(e); }
  st.busy = false; render();
}

// ---------- Eventos ----------
document.addEventListener("click", async (e) => {
  const tb = e.target.closest("#tabs button"); if (tb) { st.tab = tb.dataset.t; return render(); }
  const f = e.target.closest("[data-f]"); if (f) { st.fmt = f.dataset.f; localStorage.setItem("fmt", st.fmt); return showResult($("#res"), st.result); }
  const b = e.target.closest("[data-a]"); if (!b) return;
  const a = b.dataset.a, id = b.dataset.id;
  try {
    if (a === "new") { st.draft = { name: "", consent: false, wav: null, info: null, rec: false, secs: 0 }; sheet(); }
    else if (a === "cancel") { if (rec && rec.state === "recording") { rec.onstop = () => stream.getTracks().forEach((t) => t.stop()); rec.stop(); clearInterval(timer); } st.draft = null; sheet(); }
    else if (a === "rec") startRec();
    else if (a === "stop") rec.stop();
    else if (a === "imp") { const i = $("#file"); i.onchange = () => i.files[0] && useBlob(i.files[0]); i.click(); }
    else if (a === "saveVoice") {
      const d = st.draft, name = ($("#vname").value || "").trim(); if (!name) return toast("Ponle un nombre a la voz.");
      const v = { id: db.uid(), name, created: Date.now(), wav: d.wav, dur: d.info.dur, hz: d.info.hz };
      await db.put("voices", v); st.voices.push(v); st.sel = v.id; localStorage.setItem("sel", v.id); st.draft = null; sheet(); render(); toast("Voz guardada.");
    }
    else if (a === "play") { const au = $("#a-" + id); const v = st.voices.find((x) => x.id === id); au.src = url(v.wav); au.play(); }
    else if (a === "use") { st.sel = id; localStorage.setItem("sel", id); render(); }
    else if (a === "ren") { const v = st.voices.find((x) => x.id === id); const n = await ask("Nuevo nombre", { input: v.name, ok: "Guardar" }); if (n) { v.name = n; await db.put("voices", v); render(); } }
    else if (a === "del") { if (await ask("¿Eliminar esta voz?", { ok: "Eliminar", danger: true })) { await db.del("voices", id); await load(); render(); } }
    else if (a === "dela") { if (await ask("¿Eliminar este audio?", { ok: "Eliminar", danger: true })) { await db.del("audios", id); if (st.result?.id === id) st.result = null; await load(); render(); } }
    else if (a === "gen") generate();
    else if (a === "save") { toast("Preparando…"); await saveToPhone(findItem(id)); }
    else if (a === "share") { toast("Preparando…"); await shareAudio(findItem(id)); }
  } catch (err) { if (!/cancel/i.test(err.message || "")) toast("Error: " + (err.message || err)); console.error(err); }
});
document.addEventListener("input", (e) => {
  if (e.target.id === "txt") st.text = e.target.value;
  if (e.target.id === "vname" && st.draft) st.draft.name = e.target.value;
  if (e.target.id === "consent") { st.draft.consent = e.target.checked; sheet(); }
});
document.addEventListener("change", (e) => {
  if (e.target.id === "vsel") { st.sel = e.target.value; localStorage.setItem("sel", st.sel); }
  if (e.target.id === "lang") { st.lang = e.target.value; localStorage.setItem("lang", st.lang); }
  if (e.target.id === "space") { st.space = e.target.value.trim() || "coqui/xtts"; localStorage.setItem("space", st.space); }
});
(async () => { try { navigator.storage?.persist?.(); } catch {} await load(); render(); })();
