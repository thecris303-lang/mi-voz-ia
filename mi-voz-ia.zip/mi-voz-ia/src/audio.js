
export function toInt16(f) {
  const o = new Int16Array(f.length);
  for (let i = 0; i < f.length; i++) { const s = Math.max(-1, Math.min(1, f[i])); o[i] = s < 0 ? s * 0x8000 : s * 0x7fff; }
  return o;
}
export function encodeWav(f, rate) {
  const pcm = toInt16(f), b = new ArrayBuffer(44 + pcm.length * 2), v = new DataView(b);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, "RIFF"); v.setUint32(4, 36 + pcm.length * 2, true); w(8, "WAVEfmt "); v.setUint32(16, 16, true);
  v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true);
  v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, "data"); v.setUint32(40, pcm.length * 2, true);
  new Int16Array(b, 44).set(pcm);
  return new Uint8Array(b);
}
export const wavBlob = (f, rate) => new Blob([encodeWav(f, rate)], { type: "audio/wav" });

export function encodeMp3(f, rate) {
  const enc = new globalThis.lamejs.Mp3Encoder(1, rate, 128), pcm = toInt16(f), out = [];
  for (let i = 0; i < pcm.length; i += 1152) { const c = enc.encodeBuffer(pcm.subarray(i, i + 1152)); if (c.length) out.push(c); }
  const e = enc.flush(); if (e.length) out.push(e);
  return new Blob(out, { type: "audio/mpeg" });
}

export function concat(parts, rate, gap = 0.3) {
  const g = Math.round(rate * gap), n = parts.reduce((a, p) => a + p.length, 0) + g * Math.max(0, parts.length - 1);
  const o = new Float32Array(n); let k = 0;
  parts.forEach((p, i) => { o.set(p, k); k += p.length + (i < parts.length - 1 ? g : 0); });
  return o;
}

// Divide el texto en trozos cortos (XTTS rinde mejor con frases de menos de ~200 caracteres)
export function splitText(text, max = 200) {
  const sents = text.replace(/\s+/g, " ").trim().match(/[^.!?¡¿;:\n]+[.!?;:]*|[.!?]+/g) || [];
  const out = []; let cur = "";
  const flush = () => { if (cur.trim()) out.push(cur.trim()); cur = ""; };
  for (let s of sents) {
    s = s.trim(); if (!s) continue;
    while (s.length > max) { let cut = s.lastIndexOf(",", max); if (cut < 40) cut = s.lastIndexOf(" ", max); if (cut < 40) cut = max;
      flush(); out.push(s.slice(0, cut + 1).trim()); s = s.slice(cut + 1).trim(); }
    if ((cur + " " + s).trim().length > max) flush();
    cur = (cur + " " + s).trim();
  }
  flush(); return out;
}

// Revisión básica de la muestra: duración, volumen, saturación y tono aproximado
export function analyze(f, rate) {
  const dur = f.length / rate; let sum = 0, peak = 0, clip = 0;
  for (let i = 0; i < f.length; i++) { const a = Math.abs(f[i]); sum += a * a; if (a > peak) peak = a; if (a > 0.99) clip++; }
  const rms = Math.sqrt(sum / Math.max(1, f.length)), db = 20 * Math.log10(rms || 1e-6);
  const N = 1024, pitches = [];
  for (let s = 0; s + N < f.length && pitches.length < 120; s += Math.floor(rate * 0.1)) {
    let e = 0; for (let i = 0; i < N; i++) e += f[s + i] * f[s + i];
    if (Math.sqrt(e / N) < rms * 0.8) continue;
    let best = 0, bl = 0;
    for (let l = Math.floor(rate / 400); l <= Math.floor(rate / 75); l++) { let c = 0; for (let i = 0; i < N - l; i++) c += f[s + i] * f[s + i + l]; if (c > best) { best = c; bl = l; } }
    if (bl && best > e * 0.3) pitches.push(rate / bl);
  }
  pitches.sort((a, b) => a - b);
  const hz = pitches.length ? Math.round(pitches[pitches.length >> 1]) : null;
  const tips = [];
  if (dur < 6) tips.push("Muy corta: lo ideal son 10 a 30 segundos.");
  if (db < -35) tips.push("Volumen muy bajo: habla más cerca del micrófono.");
  if (clip / f.length > 0.002) tips.push("El audio está saturado: habla un poco más lejos.");
  return { dur, db: Math.round(db), peak, hz, tips };
}

// Solo navegador: decodifica cualquier audio a mono Float32 con la frecuencia pedida
export async function decodeBlob(blob, rate = 24000) {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const buf = await ctx.decodeAudioData(await blob.arrayBuffer()); ctx.close();
  const off = new OfflineAudioContext(1, Math.max(1, Math.ceil(buf.duration * rate)), rate);
  const src = off.createBufferSource(); src.buffer = buf; src.connect(off.destination); src.start();
  return (await off.startRendering()).getChannelData(0).slice();
}
