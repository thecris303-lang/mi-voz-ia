const open = () => new Promise((res, rej) => {
  const r = indexedDB.open("miVozIA", 1);
  r.onupgradeneeded = () => { const d = r.result; d.createObjectStore("voices", { keyPath: "id" }); d.createObjectStore("audios", { keyPath: "id" }); };
  r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
});
const tx = async (s, m, f) => { const d = await open(); return new Promise((res, rej) => {
  const t = d.transaction(s, m); const q = f(t.objectStore(s));
  t.oncomplete = () => res(q && q.result); t.onerror = () => rej(t.error); }); };
export const all = (s) => tx(s, "readonly", (o) => o.getAll());
export const put = (s, v) => tx(s, "readwrite", (o) => o.put(v));
export const del = (s, id) => tx(s, "readwrite", (o) => o.delete(id));
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
