import { build } from "esbuild";
import { mkdirSync, copyFileSync } from "fs";
mkdirSync("www", { recursive: true });
await build({ entryPoints: ["src/app.js"], bundle: true, outfile: "www/app.js", format: "iife",
  target: ["chrome90"], minify: true, define: { "process.env.NODE_ENV": '"production"', global: "globalThis" } });
for (const f of ["index.html", "styles.css"]) copyFileSync("src/" + f, "www/" + f);
copyFileSync("node_modules/lamejs/lame.min.js", "www/lame.min.js");
console.log("Web lista en www/");
